package com.my.edgepanel

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Rect

object Launcher {

    /**
     * Запускает приложение в плавающем (freeform) окне.
     * Если на телефоне не включены «окна произвольной формы» — приложение откроется обычным образом.
     */
    fun launchFloating(ctx: Context, pkg: String, cfg: Cfg): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        val dm = ctx.resources.displayMetrics
        val w = (dm.widthPixels * Cfg.WIN_W[cfg.winSize.coerceIn(0, 2)]).toInt()
        val h = (dm.heightPixels * Cfg.WIN_H[cfg.winSize.coerceIn(0, 2)]).toInt()
        val left = (dm.widthPixels - w) / 2
        val top = (dm.heightPixels * 0.14f).toInt()

        val opts = ActivityOptions.makeBasic()
        opts.setLaunchBounds(Rect(left, top, left + w, top + h))
        try {
            // 5 = WINDOWING_MODE_FREEFORM (скрытый API, на части прошивок срабатывает)
            ActivityOptions::class.java
                .getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
                .invoke(opts, 5)
        } catch (_: Throwable) {
            // не страшно: останется обычный запуск с заданными границами
        }

        return try {
            ctx.startActivity(intent, opts.toBundle())
            true
        } catch (e: Exception) {
            false
        }
    }
}
