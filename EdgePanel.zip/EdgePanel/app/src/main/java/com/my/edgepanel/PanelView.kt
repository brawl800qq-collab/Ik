package com.my.edgepanel

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.ceil

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/**
 * Стеклянная панель, которая выезжает от края экрана.
 * Внутри: сетка приложений, кнопки настроек/закрытия и выбор размера окна.
 */
class PanelView(
    context: Context,
    private val cfg: Cfg,
    private val onLaunch: (String) -> Unit,
    private val onClose: () -> Unit,
    private val onSettings: () -> Unit
) : FrameLayout(context) {

    private val accent = cfg.accentColor
    private val right = cfg.side == 1
    private val scrim = View(context)
    private val card = LinearLayout(context)
    private val tiles = ArrayList<View>()
    private var slideDist = 0f
    private var closing = false

    init {
        isFocusableInTouchMode = true

        // затемнение фона: тап или свайп к краю закрывает панель
        scrim.setBackgroundColor(0xA6000000.toInt())
        scrim.alpha = 0f
        var startX = 0f
        scrim.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> startX = e.rawX
                MotionEvent.ACTION_MOVE -> {
                    val d = e.rawX - startX
                    if ((right && d > 60.dp) || (!right && d < -60.dp)) onClose()
                }
                MotionEvent.ACTION_UP -> onClose()
            }
            true
        }
        addView(scrim, LayoutParams(MATCH, MATCH))
        buildCard()
    }

    // ---------------------------------------------------------------- карточка

    private fun buildCard() {
        val dm = resources.displayMetrics
        val w = minOf(324.dp, dm.widthPixels - 28.dp)
        slideDist = (if (right) 1f else -1f) * (w + 28.dp)

        card.orientation = LinearLayout.VERTICAL
        card.setPadding(16.dp, 10.dp, 16.dp, 16.dp)
        card.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xF2202033.toInt(), 0xF20C0C16.toInt())
        ).apply {
            cornerRadius = 30f.dp
            setStroke(1.dp, Ui.alpha(accent, 110))
        }
        card.isClickable = true
        card.translationX = slideDist

        val lp = LayoutParams(w, WRAP, (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL)
        lp.setMargins(12.dp, 0, 12.dp, 0)
        addView(card, lp)

        // «ручка» сверху карточки
        val grab = View(context)
        grab.background = Ui.round(Ui.alpha(accent, 200), 3f)
        val glp = LinearLayout.LayoutParams(36.dp, 4.dp)
        glp.gravity = Gravity.CENTER_HORIZONTAL
        glp.bottomMargin = 10.dp
        card.addView(grab, glp)

        card.addView(buildHeader(), LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(divider(), dividerParams(12, 4))

        val apps = cfg.apps.filter { context.packageManager.getLaunchIntentForPackage(it) != null }
        if (apps.isEmpty()) buildEmpty() else buildGrid(apps, dm.heightPixels)

        card.addView(divider(), dividerParams(6, 12))
        card.addView(buildFooter(), LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun buildHeader(): View {
        val header = LinearLayout(context)
        header.gravity = Gravity.CENTER_VERTICAL

        val titles = LinearLayout(context)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(Ui.text(context, "Мини-окна", 19f, Color.WHITE, true))
        titles.addView(Ui.text(context, "Приложение поверх текущего", 12f, Ui.alpha(Color.WHITE, 140)))
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))

        val sLp = LinearLayout.LayoutParams(36.dp, 36.dp)
        sLp.marginEnd = 8.dp
        header.addView(iconButton(R.drawable.ic_settings) { onSettings() }, sLp)
        header.addView(iconButton(R.drawable.ic_close) { onClose() }, LinearLayout.LayoutParams(36.dp, 36.dp))
        return header
    }

    private fun iconButton(res: Int, click: () -> Unit): View {
        val b = FrameLayout(context)
        b.background = Ui.oval(Ui.alpha(Color.WHITE, 30))
        val iv = ImageView(context)
        iv.setImageResource(res)
        b.addView(iv, LayoutParams(18.dp, 18.dp, Gravity.CENTER))
        b.setOnClickListener { click() }
        Ui.press(b)
        return b
    }

    private fun divider(): View {
        val v = View(context)
        v.setBackgroundColor(Ui.alpha(Color.WHITE, 26))
        return v
    }

    private fun dividerParams(topDp: Int, bottomDp: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, 1.dp)
        lp.topMargin = topDp.dp
        lp.bottomMargin = bottomDp.dp
        return lp
    }

    // ---------------------------------------------------------------- приложения

    private fun buildGrid(apps: List<String>, screenH: Int) {
        val rows = ceil(apps.size / 3.0).toInt()
        val contentH = rows * 96.dp
        val scrollH = minOf(contentH, (screenH * 0.46f).toInt())

        val grid = LinearLayout(context)
        grid.orientation = LinearLayout.VERTICAL

        apps.chunked(3).forEach { chunk ->
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            for (i in 0 until 3) {
                val cell = if (i < chunk.size) appItem(chunk[i]) else View(context)
                row.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
            grid.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }

        val scroll = ScrollView(context)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.addView(grid, LayoutParams(MATCH, WRAP))
        card.addView(scroll, LinearLayout.LayoutParams(MATCH, scrollH))
    }

    private fun appItem(pkg: String): View {
        val pm = context.packageManager
        val icon = ImageView(context)
        val label = try {
            icon.setImageDrawable(pm.getApplicationIcon(pkg))
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            return View(context)
        }

        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(2.dp, 8.dp, 2.dp, 8.dp)

        val tile = FrameLayout(context)
        tile.background = Ui.round(Ui.alpha(Color.WHITE, 22), 18f, Ui.alpha(Color.WHITE, 30), 1)
        tile.addView(icon, LayoutParams(40.dp, 40.dp, Gravity.CENTER))
        col.addView(tile, LinearLayout.LayoutParams(58.dp, 58.dp))

        val name = Ui.text(context, label, 11f, Ui.alpha(Color.WHITE, 220))
        name.gravity = Gravity.CENTER
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        val nlp = LinearLayout.LayoutParams(MATCH, WRAP)
        nlp.topMargin = 6.dp
        col.addView(name, nlp)

        col.alpha = 0f
        col.setOnClickListener { onLaunch(pkg) }
        Ui.press(col)
        tiles.add(col)
        return col
    }

    private fun buildEmpty() {
        val box = LinearLayout(context)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(0, 22.dp, 0, 22.dp)

        val msg = Ui.text(context, "В панели пока пусто.\nВыбери приложения в настройках.", 13f, Ui.alpha(Color.WHITE, 170))
        msg.gravity = Gravity.CENTER
        box.addView(msg)

        val btn = Ui.text(context, "Открыть настройки", 14f, Ui.onAccent(accent), true)
        btn.gravity = Gravity.CENTER
        btn.setPadding(22.dp, 0, 22.dp, 0)
        btn.background = Ui.round(accent, 16f)
        btn.setOnClickListener { onSettings() }
        Ui.press(btn)
        val blp = LinearLayout.LayoutParams(WRAP, 42.dp)
        blp.topMargin = 14.dp
        box.addView(btn, blp)

        card.addView(box, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    // ---------------------------------------------------------------- низ панели

    private fun buildFooter(): View {
        val row = LinearLayout(context)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(
            Ui.text(context, "Размер окна", 12f, Ui.alpha(Color.WHITE, 150)),
            LinearLayout.LayoutParams(0, WRAP, 1f)
        )
        val seg = Ui.segmented(context, listOf("S", "M", "L"), cfg.winSize.coerceIn(0, 2), accent) {
            cfg.winSize = it
        }
        row.addView(seg, LinearLayout.LayoutParams(150.dp, WRAP))
        return row
    }

    // ---------------------------------------------------------------- анимации

    fun show() {
        requestFocus()
        scrim.animate().alpha(1f).setDuration(240).start()
        card.animate().translationX(0f).setDuration(300)
            .setInterpolator(DecelerateInterpolator(2f)).start()
        tiles.forEachIndexed { i, v ->
            v.alpha = 0f
            v.scaleX = 0.85f
            v.scaleY = 0.85f
            v.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(120L + i * 28L).setDuration(220).start()
        }
    }

    fun hide(end: () -> Unit) {
        if (closing) return
        closing = true
        scrim.animate().alpha(0f).setDuration(180).start()
        card.animate().translationX(slideDist).alpha(0f).setDuration(200)
            .setInterpolator(AccelerateInterpolator()).withEndAction(end).start()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
            onClose()
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
