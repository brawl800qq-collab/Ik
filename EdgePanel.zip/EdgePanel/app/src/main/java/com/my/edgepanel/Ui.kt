package com.my.edgepanel

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Маленькие помощники для рисования интерфейса из кода. */
object Ui {

    fun alpha(color: Int, a: Int): Int =
        (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    fun round(color: Int, radiusDp: Float, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radiusDp.dp
        if (strokeDp > 0) d.setStroke(strokeDp.dp, stroke)
        return d
    }

    fun oval(color: Int, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(color)
        if (strokeDp > 0) d.setStroke(strokeDp.dp, stroke)
        return d
    }

    /** Цвет текста поверх акцентного цвета: тёмный на светлом, белый на тёмном. */
    fun onAccent(accent: Int): Int {
        val l = (0.299 * Color.red(accent) + 0.587 * Color.green(accent) +
                0.114 * Color.blue(accent)) / 255.0
        return if (l > 0.6) 0xFF101018.toInt() else Color.WHITE
    }

    fun text(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    /** Лёгкое «вдавливание» при нажатии. */
    fun press(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }
    }

    /** Переключатель «таблетка»: [ A | B | C ]. */
    fun segmented(
        ctx: Context,
        labels: List<String>,
        selected: Int,
        accent: Int,
        onSelect: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.HORIZONTAL
        box.setPadding(3.dp, 3.dp, 3.dp, 3.dp)
        box.background = round(alpha(Color.WHITE, 24), 14f)
        val views = ArrayList<TextView>()

        fun paint(sel: Int) {
            views.forEachIndexed { i, tv ->
                if (i == sel) {
                    tv.background = round(accent, 11f)
                    tv.setTextColor(onAccent(accent))
                } else {
                    tv.background = null
                    tv.setTextColor(alpha(Color.WHITE, 170))
                }
            }
        }

        labels.forEachIndexed { i, s ->
            val tv = TextView(ctx)
            tv.text = s
            tv.gravity = Gravity.CENTER
            tv.textSize = 13f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setOnClickListener {
                paint(i)
                onSelect(i)
            }
            box.addView(tv, LinearLayout.LayoutParams(0, 32.dp, 1f))
            views.add(tv)
        }
        paint(selected)
        return box
    }
}
