package com.my.edgepanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.WindowManager
import kotlin.math.abs

/**
 * Живёт в фоне, держит у края экрана тонкую ручку.
 * Свайп от края (или тап по ручке) открывает панель с приложениями.
 */
class EdgeService : Service() {

    companion object {
        const val ACTION_STOP = "com.my.edgepanel.STOP"
        const val ACTION_REFRESH = "com.my.edgepanel.REFRESH"
        private const val CHANNEL = "edge_panel"

        @Volatile
        var running = false

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, EdgeService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, EdgeService::class.java))
        }

        /** Перерисовать ручку после смены настроек. */
        fun refresh(ctx: Context) {
            if (running) {
                ctx.startService(Intent(ctx, EdgeService::class.java).setAction(ACTION_REFRESH))
            }
        }
    }

    private lateinit var cfg: Cfg
    private lateinit var wm: WindowManager
    private var handle: HandleView? = null
    private var panel: PanelView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        cfg = Cfg(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        running = true
        addHandle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> {
                if (running) {
                    closePanel(animated = false)
                    addHandle()
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        closePanel(animated = false)
        removeHandle()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- ручка

    private fun addHandle() {
        removeHandle()
        val h = HandleView(this, cfg)
        val dm = resources.displayMetrics
        val hPx = cfg.handleHeight.dp

        val lp = WindowManager.LayoutParams(
            24.dp, hPx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or (if (cfg.side == 1) Gravity.END else Gravity.START)
        lp.x = 0
        lp.y = ((dm.heightPixels - hPx) * cfg.handleOffset / 100f).toInt()

        // чтобы системный жест «назад» не перехватывал свайп у края
        if (Build.VERSION.SDK_INT >= 29) {
            h.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
                v.systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
            }
        }

        var downX = 0f
        var downY = 0f
        var fired = false
        h.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    fired = false
                    h.setPressedState(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val inward = if (cfg.side == 1) -dx else dx
                    if (!fired && inward > 16.dp && abs(e.rawY - downY) < inward * 2f) {
                        fired = true
                        openPanel()
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!fired && abs(e.rawX - downX) < 8.dp && abs(e.rawY - downY) < 8.dp) {
                        openPanel()
                    }
                    h.setPressedState(false)
                }
                MotionEvent.ACTION_CANCEL -> h.setPressedState(false)
            }
            true
        }

        try {
            wm.addView(h, lp)
            handle = h
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun removeHandle() {
        handle?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        handle = null
    }

    // ---------------------------------------------------------------- панель

    private fun openPanel() {
        if (panel != null) return

        val p = PanelView(
            this, cfg,
            onLaunch = { pkg ->
                // сначала запускаем (пока наше окно видимо), потом закрываем панель
                Launcher.launchFloating(this, pkg, cfg)
                closePanel(animated = true)
            },
            onClose = { closePanel(animated = true) },
            onSettings = {
                closePanel(animated = true)
                startActivity(
                    Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        )

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES

        // размытие фона за панелью, если прошивка это умеет (Android 12+)
        if (Build.VERSION.SDK_INT >= 31 && cfg.blur && wm.isCrossWindowBlurEnabled) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 28
        }

        try {
            wm.addView(p, lp)
            panel = p
            p.show()
            p.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        } catch (e: Exception) {
            panel = null
        }
    }

    private fun closePanel(animated: Boolean) {
        val p = panel ?: return
        panel = null
        val remove = {
            try {
                wm.removeView(p)
            } catch (_: Exception) {
            }
        }
        if (animated) p.hide { remove() } else remove()
    }

    // ---------------------------------------------------------------- уведомление

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Edge Panel", NotificationManager.IMPORTANCE_MIN)
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, EdgeService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_handle)
            .setContentTitle("Edge Panel работает")
            .setContentText("Свайп от края экрана открывает панель")
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_close), "Выключить", stop
                ).build()
            )
            .setOngoing(true)
            .build()
        startForeground(1, n)
    }
}
