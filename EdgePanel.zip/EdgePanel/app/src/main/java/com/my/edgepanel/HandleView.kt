package com.my.edgepanel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Тонкая светящаяся ручка у края экрана. За неё свайпаем. */
class HandleView(context: Context, private val cfg: Cfg) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        alpha = 0.7f
    }

    fun setPressedState(on: Boolean) {
        animate().alpha(if (on) 1f else 0.7f)
            .scaleY(if (on) 1.06f else 1f)
            .setDuration(120).start()
    }

    override fun onDraw(canvas: Canvas) {
        val accent = cfg.accentColor
        val w = width.toFloat()
        val h = height.toFloat()
        val pw = 4.dp.toFloat()
        val margin = 8.dp.toFloat()
        val x0 = if (cfg.side == 1) w - pw - margin else margin
        val ph = h * 0.62f
        val top = (h - ph) / 2f

        // мягкое свечение: три слоя с растущим радиусом
        for (i in 3 downTo 1) {
            paint.color = Ui.alpha(accent, 22 * (4 - i))
            val g = i * 2.dp.toFloat()
            canvas.drawRoundRect(
                x0 - g, top - g, x0 + pw + g, top + ph + g,
                pw / 2f + g, pw / 2f + g, paint
            )
        }
        paint.color = accent
        canvas.drawRoundRect(x0, top, x0 + pw, top + ph, pw / 2f, pw / 2f, paint)
    }
}
