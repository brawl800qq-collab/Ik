package com.my.edgepanel

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Экран настроек: включение панели, внешний вид, выбор приложений. */
class MainActivity : Activity() {

    data class AppItem(val pkg: String, val label: String)

    private lateinit var cfg: Cfg
    private lateinit var mainBtn: TextView
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var countText: TextView
    private lateinit var adapter: AppsAdapter
    private var accent = 0

    private val bg = 0xFF0B0B12.toInt()
    private val card = 0xFF15151F.toInt()
    private val dim = Ui.alpha(Color.WHITE, 140)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        accent = cfg.accentColor

        val list = ListView(this)
        list.setBackgroundColor(bg)
        list.divider = null
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.addHeaderView(buildHeader(), null, false)
        adapter = AppsAdapter()
        list.adapter = adapter
        setContentView(list)

        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(q, 0)
                .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .distinctBy { it.pkg }
                .filter { it.pkg != packageName }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                adapter.items = apps
                adapter.notifyDataSetChanged()
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        adapter.notifyDataSetChanged()
        updateCount()
    }

    // ---------------------------------------------------------------- шапка

    private fun lpTop(topDp: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = topDp.dp
        return lp
    }

    private fun section(title: String): TextView =
        Ui.text(this, title.uppercase(), 12f, dim, true).also { it.letterSpacing = 0.08f }

    private fun buildHeader(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(20.dp, 28.dp, 20.dp, 8.dp)

        root.addView(Ui.text(this, "Edge Panel", 30f, Color.WHITE, true))
        root.addView(Ui.text(this, "Мини-окна одним свайпом от края экрана", 14f, dim), lpTop(4))

        // --- карточка статуса
        val sc = LinearLayout(this)
        sc.orientation = LinearLayout.VERTICAL
        sc.setPadding(18.dp, 18.dp, 18.dp, 18.dp)
        sc.background = Ui.round(card, 22f, Ui.alpha(accent, 90), 1)

        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        statusDot = View(this)
        val dotLp = LinearLayout.LayoutParams(10.dp, 10.dp)
        dotLp.marginEnd = 10.dp
        row.addView(statusDot, dotLp)
        statusText = Ui.text(this, "", 15f, Color.WHITE, true)
        row.addView(statusText)
        sc.addView(row)

        mainBtn = Ui.text(this, "", 16f, Ui.onAccent(accent), true)
        mainBtn.gravity = Gravity.CENTER
        mainBtn.background = Ui.round(accent, 16f)
        mainBtn.setOnClickListener { onMainClick() }
        Ui.press(mainBtn)
        val btnLp = LinearLayout.LayoutParams(MATCH, 50.dp)
        btnLp.topMargin = 16.dp
        sc.addView(mainBtn, btnLp)
        root.addView(sc, lpTop(22))

        // --- сторона
        root.addView(section("Сторона экрана"), lpTop(26))
        root.addView(
            Ui.segmented(this, listOf("Слева", "Справа"), cfg.side, accent) {
                cfg.side = it
                EdgeService.refresh(this)
            }, lpTop(10)
        )

        // --- ручка
        root.addView(section("Ручка"), lpTop(24))
        root.addView(sliderRow("Высота", 80, 200, cfg.handleHeight, "dp") {
            cfg.handleHeight = it
            EdgeService.refresh(this)
        }, lpTop(8))
        root.addView(sliderRow("Положение по вертикали", 0, 100, cfg.handleOffset, "%") {
            cfg.handleOffset = it
            EdgeService.refresh(this)
        }, lpTop(4))

        // --- цвет
        root.addView(section("Цвет"), lpTop(24))
        val sw = LinearLayout(this)
        Cfg.ACCENTS.forEachIndexed { i, c ->
            val d = View(this)
            d.background = if (i == cfg.accent) Ui.oval(c, Color.WHITE, 3) else Ui.oval(c)
            d.setOnClickListener {
                cfg.accent = i
                EdgeService.refresh(this)
                recreate()
            }
            val lp = LinearLayout.LayoutParams(40.dp, 40.dp)
            lp.marginEnd = 12.dp
            sw.addView(d, lp)
        }
        root.addView(sw, lpTop(12))

        // --- размер мини-окна
        root.addView(section("Размер мини-окна"), lpTop(24))
        root.addView(
            Ui.segmented(this, listOf("S", "M", "L"), cfg.winSize.coerceIn(0, 2), accent) {
                cfg.winSize = it
            }, lpTop(10)
        )

        // --- переключатели
        root.addView(section("Поведение"), lpTop(24))
        root.addView(
            switchRow("Размытие фона", "Если прошивка поддерживает", cfg.blur) { cfg.blur = it },
            lpTop(6)
        )
        root.addView(
            switchRow("Запуск после перезагрузки", "Панель включается сама", cfg.autostart) { cfg.autostart = it },
            lpTop(2)
        )

        // --- подсказка про плавающие окна
        val tip = LinearLayout(this)
        tip.orientation = LinearLayout.VERTICAL
        tip.setPadding(18.dp, 16.dp, 18.dp, 16.dp)
        tip.background = Ui.round(card, 20f, Ui.alpha(Color.WHITE, 24), 1)
        tip.addView(Ui.text(this, "Чтобы окна были плавающими", 15f, Color.WHITE, true))
        val tipBody = Ui.text(
            this,
            "Настройки → Для разработчиков: включи «Разрешить окна произвольной формы» и " +
                    "«Изменение размера в многооконном режиме», затем перезагрузи телефон. " +
                    "Без этого приложения откроются обычным способом.",
            13f, dim
        )
        tipBody.setLineSpacing(3.dp.toFloat(), 1f)
        tip.addView(tipBody, lpTop(6))
        val devBtn = Ui.text(this, "Открыть «Для разработчиков»", 14f, accent, true)
        devBtn.setPadding(0, 12.dp, 0, 0)
        devBtn.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Включи режим разработчика (7 тапов по номеру сборки)", Toast.LENGTH_LONG).show()
            }
        }
        tip.addView(devBtn)
        root.addView(tip, lpTop(22))

        // --- приложения
        root.addView(section("Приложения в панели"), lpTop(28))
        countText = Ui.text(this, "", 13f, dim)
        root.addView(countText, lpTop(4))
        return root
    }

    private fun sliderRow(
        title: String, lo: Int, hi: Int, value: Int, unit: String, onChange: (Int) -> Unit
    ): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL

        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.text(this, title, 14f, Color.WHITE), LinearLayout.LayoutParams(0, WRAP, 1f))
        val valueText = Ui.text(this, "$value $unit", 13f, dim)
        top.addView(valueText)
        box.addView(top)

        val seek = SeekBar(this)
        seek.max = hi - lo
        seek.progress = value.coerceIn(lo, hi) - lo
        seek.progressTintList = ColorStateList.valueOf(accent)
        seek.thumbTintList = ColorStateList.valueOf(accent)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                valueText.text = "${p + lo} $unit"
            }

            override fun onStartTrackingTouch(s: SeekBar) {}

            override fun onStopTrackingTouch(s: SeekBar) {
                onChange(s.progress + lo)
            }
        })
        box.addView(seek, LinearLayout.LayoutParams(MATCH, WRAP))
        return box
    }

    private fun switchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, 8.dp, 0, 8.dp)

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(Ui.text(this, title, 15f, Color.WHITE))
        texts.addView(Ui.text(this, sub, 12f, dim))
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))

        val sw = Switch(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, c -> onChange(c) }
        row.addView(sw)
        return row
    }

    // ---------------------------------------------------------------- статус

    private fun onMainClick() {
        when {
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            EdgeService.running -> EdgeService.stop(this)
            else -> EdgeService.start(this)
        }
        mainBtn.postDelayed({ refreshStatus() }, 400)
    }

    private fun refreshStatus() {
        val perm = Settings.canDrawOverlays(this)
        val on = perm && EdgeService.running
        when {
            !perm -> {
                statusText.text = "Нужно разрешение «Поверх других окон»"
                mainBtn.text = "Дать разрешение"
                statusDot.background = Ui.oval(0xFFFFB84D.toInt())
            }
            on -> {
                statusText.text = "Панель активна"
                mainBtn.text = "Выключить"
                statusDot.background = Ui.oval(0xFF2EE6A6.toInt())
            }
            else -> {
                statusText.text = "Панель выключена"
                mainBtn.text = "Включить"
                statusDot.background = Ui.oval(Ui.alpha(Color.WHITE, 90))
            }
        }
    }

    private fun updateCount() {
        countText.text = "Выбрано ${cfg.apps.size} из ${Cfg.MAX_APPS}. Цифра справа — порядок в панели."
    }

    private fun toggle(pkg: String) {
        val cur = cfg.apps.toMutableList()
        if (cur.contains(pkg)) {
            cur.remove(pkg)
        } else {
            if (cur.size >= Cfg.MAX_APPS) {
                Toast.makeText(this, "Максимум ${Cfg.MAX_APPS} приложений", Toast.LENGTH_SHORT).show()
                return
            }
            cur.add(pkg)
        }
        cfg.apps = cur
        adapter.notifyDataSetChanged()
        updateCount()
    }

    // ---------------------------------------------------------------- список приложений

    inner class AppsAdapter : BaseAdapter() {
        var items: List<AppItem> = emptyList()
        private val icons = HashMap<String, Drawable?>()

        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        private fun buildRow(): LinearLayout {
            val row = LinearLayout(this@MainActivity)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(20.dp, 10.dp, 20.dp, 10.dp)

            val icon = ImageView(this@MainActivity)
            val iLp = LinearLayout.LayoutParams(42.dp, 42.dp)
            iLp.marginEnd = 14.dp
            row.addView(icon, iLp)

            val name = Ui.text(this@MainActivity, "", 15f, Color.WHITE)
            name.maxLines = 1
            name.ellipsize = TextUtils.TruncateAt.END
            row.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))

            val badge = Ui.text(this@MainActivity, "", 12f, Color.WHITE, true)
            badge.gravity = Gravity.CENTER
            row.addView(badge, LinearLayout.LayoutParams(26.dp, 26.dp))
            return row
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: buildRow()
            val item = items[position]

            val icon = row.getChildAt(0) as ImageView
            val name = row.getChildAt(1) as TextView
            val badge = row.getChildAt(2) as TextView

            val d = icons.getOrPut(item.pkg) {
                try {
                    packageManager.getApplicationIcon(item.pkg)
                } catch (e: PackageManager.NameNotFoundException) {
                    null
                }
            }
            icon.setImageDrawable(d)
            name.text = item.label

            val index = cfg.apps.indexOf(item.pkg)
            if (index >= 0) {
                badge.text = (index + 1).toString()
                badge.setTextColor(Ui.onAccent(accent))
                badge.background = Ui.oval(accent)
            } else {
                badge.text = ""
                badge.background = Ui.oval(Color.TRANSPARENT, Ui.alpha(Color.WHITE, 90), 2)
            }

            row.setOnClickListener { toggle(item.pkg) }
            return row
        }
    }
}
