package com.my.edgepanel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
            Cfg(context).autostart &&
            Settings.canDrawOverlays(context)
        ) {
            EdgeService.start(context)
        }
    }
}
