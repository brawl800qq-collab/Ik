package com.my.edgepanel

import android.content.Context
import android.content.res.Resources

val Int.dp: Int get() = (this * Resources.getSystem().displayMetrics.density + 0.5f).toInt()
val Float.dp: Float get() = this * Resources.getSystem().displayMetrics.density

/** Все настройки приложения в одном месте. */
class Cfg(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("edge_cfg", Context.MODE_PRIVATE)

    /** 0 = слева, 1 = справа */
    var side: Int
        get() = sp.getInt("side", 1)
        set(v) { sp.edit().putInt("side", v).apply() }

    /** высота ручки, dp */
    var handleHeight: Int
        get() = sp.getInt("hh", 150)
        set(v) { sp.edit().putInt("hh", v).apply() }

    /** положение ручки по вертикали, 0..100 % */
    var handleOffset: Int
        get() = sp.getInt("ho", 50)
        set(v) { sp.edit().putInt("ho", v).apply() }

    var accent: Int
        get() = sp.getInt("accent", 0)
        set(v) { sp.edit().putInt("accent", v).apply() }

    /** размер мини-окна: 0 = S, 1 = M, 2 = L */
    var winSize: Int
        get() = sp.getInt("win", 1)
        set(v) { sp.edit().putInt("win", v).apply() }

    var blur: Boolean
        get() = sp.getBoolean("blur", true)
        set(v) { sp.edit().putBoolean("blur", v).apply() }

    var autostart: Boolean
        get() = sp.getBoolean("auto", false)
        set(v) { sp.edit().putBoolean("auto", v).apply() }

    /** пакеты приложений в панели, в порядке выбора */
    var apps: List<String>
        get() = (sp.getString("apps", "") ?: "").split("|").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("apps", v.joinToString("|")).apply() }

    val accentColor: Int
        get() = ACCENTS[accent.coerceIn(0, ACCENTS.size - 1)]

    companion object {
        const val MAX_APPS = 12

        val ACCENTS = intArrayOf(
            0xFF7C5CFF.toInt(), // фиолетовый
            0xFF00D4FF.toInt(), // голубой
            0xFF2EE6A6.toInt(), // мятный
            0xFFFF5C8A.toInt(), // розовый
            0xFFFFB84D.toInt(), // янтарный
            0xFFFFFFFF.toInt()  // белый
        )

        // доли экрана для мини-окна: S / M / L
        val WIN_W = floatArrayOf(0.58f, 0.78f, 0.94f)
        val WIN_H = floatArrayOf(0.38f, 0.52f, 0.68f)
    }
}
